// https://vjudge.net/problem/LightOJ-1059
// http://isaac.lsu.edu/uva/117/p11733.pdf

//by Ankita Gupta

#include<bits/stdc++.h>
using namespace std;

int main(){
    int t;
    cin>>t;

    while(t--)
    {

    }
}